library(tidyverse)
library(Hmisc) #for correlation matrix with significance levels

#The following code produces Cross-sectional Correlations between LFP and Candidate Firearm Proxies. 
#It produces Table 2 and Table 9.

##################################################################################################
#%%%%%TABLE 2 CROSS-SECTIONAL CORRELATIONS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
##################################################################################################

#Load datafile "xsection_allyrs.rds" 
#This file is county-level data for all proxies that shows aggregate 8yr snapshot (2010-2017).
dat <- readRDS("replication_code/data/xsection_allyrs.rds") 

#divide lfp and proxies (excluding FSS) by population 
dataX <- dat %>% 
  mutate_at(vars(lfp:ffl),~.x/CENSUS2010POP)

#clean and reorder dataframe to run correlation matrix
#do not select ffl here because ffl only uses 4 yrs of data (2014-2017).
#for apples-to-apples comparison, 
#we will compare ffl with matching 4 yrs cross-section data rather than to 8 yrs
dataX2 <- dataX %>% 
  select(-state_county_fips,-CENSUS2010POP) %>%
  select(lfp, str, os) #this reorders the vars

#Run correlation matrix using Hmisc package rcorr command
table1a <- rcorr(as.matrix(dataX2), type="pearson")

#correlation values
round(table1a$r, digit=2)
#pvalues
round(table1a$P, digit=2)

#We compare ffl/Pop. with other proxies/Pop. using matching 4 yrs cross-section data (2014-2017)
#Load datafile "xsection_4yrs.rds" 
dat2 <- readRDS("replication_code/data/xsection_4yrs.rds") 

#divide lfp and proxies by population 
dataX3 <- dat2 %>% 
  mutate_at(vars(lfp:ffl),~.x/CENSUS2010POP)

#clean and reorder dataframe to run correlation matrix
dataX4 <- dataX3 %>% 
  select(-state_county_fips,-CENSUS2010POP) %>%
  select(lfp, str, os, ffl) #this reorders the vars

#Run correlation of ffl to all other proxies
round(cor(dataX4[ , colnames(dataX4) != "ffl"], dataX4$ffl), digit=2)

...#p-values
cor.test(dataX4$lfp, dataX4$ffl) #pval 0.03563
cor.test(dataX4$str, dataX4$ffl) #pval 0.002
cor.test(dataX4$os, dataX4$ffl) #pval 0.1236

##################################################################################################
#%%%%%TABLE 9 CROSS-SECTIONAL BIENNIAL CORRELATIONS%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
##################################################################################################

##############################################
#code for 2010-2011 
##############################################
crossdat <- readRDS("replication_code/data/xsection_2yrs_10-11.rds") %>%
  mutate_all(as.numeric)

#divide lfp and proxies (excluding fss) by population 
crossdat2 <- crossdat %>% 
  mutate_at(vars(lfp:os),~.x/CENSUS2010POP)

#re-order variables and remove unneeded vars
crossdat2 <- crossdat2 %>%
  select(-state_county_fip, -CENSUS2010POP) %>%
  select(lfp, str, os)

## Compute Correlation matrix - output shows r and pvalues 
cor_2010_2011 <- rcorr(as.matrix(crossdat2),type = "pearson")
cor_2010_2011

##############################################
#code for 2012-2013 
##############################################
crossdat <- readRDS("replication_code/data/xsection_2yrs_12-13.rds") %>%
  mutate_all(as.numeric)

#divide lfp and proxies (excluding FSS) by population 
crossdat2 <- crossdat %>% 
  mutate_at(vars(lfp:os),~.x/CENSUS2010POP)

#re-order variables and remove unneeded vars
crossdat2 <- crossdat2 %>%
  select(-state_county_fip, -CENSUS2010POP) %>%
  select(lfp, str, os)

## Compute Correlation matrix - output shows r and pvalues 
cor_2012_2013 <- rcorr(as.matrix(crossdat2),type = "pearson")
cor_2012_2013

##############################################
#code for 2014-2015 
##############################################
crossdat <- readRDS("replication_code/data/xsection_2yrs_14-15.rds") %>%
  mutate_all(as.numeric)

#divide lfp and proxies (excluding FSS) by population 
crossdat2 <- crossdat %>% 
  select(state_county_fip, lfp, str, os,  ffl, CENSUS2010POP) %>%
  mutate_at(vars(lfp:ffl),~.x/CENSUS2010POP)

#re-order variables and remove unneeded vars
crossdat2 <- crossdat2 %>%
  select(-state_county_fip, -CENSUS2010POP) %>%
  select(lfp, str, os, ffl)

## Compute Correlation matrix - output shows r and pvalues 
cor_2014_2015 <- rcorr(as.matrix(crossdat2),type = "pearson")
cor_2014_2015

##############################################
#code for 2016-2017 
##############################################
crossdat <- readRDS("replication_code/data/xsection_2yrs_16-17.rds") %>%
  mutate_all(as.numeric)

#divide lfp and proxies (excluding FSS) by population 
crossdat2 <- crossdat %>% 
  select(state_county_fip, lfp, str, os, ffl, CENSUS2010POP) %>%
  mutate_at(vars(lfp:ffl),~.x/CENSUS2010POP)

#re-order variables and remove unneeded vars
crossdat2 <- crossdat2 %>%
  select(-state_county_fip, -CENSUS2010POP) %>%
  select(lfp, str, os, ffl)

## Compute Correlation matrix - output shows r and pvalues 
cor_2016_2017 <- rcorr(as.matrix(crossdat2),type = "pearson")
cor_2016_2017


