library(tidyverse)
library(lubridate)
library(Hmisc)

#################################################################################
###FIGURE 2 and FIGURE 6 Panel (b) are identical: LFP By County with 100% backfill
#################################################################################

#read in county-yr-month panel data
ctydat <- readRDS("replication_code/data/county_yr_month_full_panel.rds") %>%
  select(month_yr, county_name, lfp, CENSUS2010POP) 

#transform proxy variables to divide by population
ctydat <- ctydat %>% 
  mutate(lfp= lfp/CENSUS2010POP)

#Graph LFP by counties
windowsFonts(Times=windowsFont("Times New Roman"))
fig2 <- ctydat %>%
  ggplot(aes(x = month_yr, y= lfp, shape = as.factor(county_name))) +
  geom_line(color = 'black') +
  geom_point(color = 'black')+
  labs(x = "Year-Month", y= "LFP/Pop.")+
  scale_shape_manual(name= "Counties: ", values = c(0,1,2,12,19, 11, 4, 6, 17, 8, 5, 18, 15, 3),
                     labels= c("Barnstable", "Berkshire", "Bristol", "Dukes", "Essex", "Franklin",
                               "Hampden", "Hampshire", "Middlesex", "Nantucket", "Norfolk",
                               "Plymouth", "Suffolk", "Worcester"))+
  scale_y_continuous(labels = function(x) paste0(x*100, "%"), expand = c(0, 0), limits = c(0, 0.17))+
  theme_classic()+
  theme(legend.position="bottom", text=element_text(family="Times"),
        axis.text=element_text(size=14), axis.title=element_text(size=14,face="bold"),
        legend.title= element_text(size=12), legend.text= element_text(size=12))

fig2


#################################################################################
###FIGURE 6 panel (a): LFP By County with no backfill
#################################################################################

#read in county-yr-month panel data
ctydat_nobackfill <- readRDS("replication_code/data/county_yr_month_full_panel_nobackfill.rds") %>%
  select(month_yr, county_name, lfp, CENSUS2010POP) 

#transform lfp (divide by population)
ctydat_nobackfill <- ctydat_nobackfill %>% 
  mutate(lfp= lfp/CENSUS2010POP)

#Graph LFP by counties
windowsFonts(Times=windowsFont("Times New Roman"))
fig6 <- ctydat_nobackfill %>%
  ggplot(aes(x = month_yr, y= lfp, shape = as.factor(county_name))) +
  geom_line(color = 'black') +
  geom_point(color = 'black')+
  labs(x = "Year-Month", y= "LFP/Pop.")+
  scale_shape_manual(name= "Counties: ", values = c(0,1,2,12,19, 11, 4, 6, 17, 8, 5, 18, 15, 3),
                     labels= c("Barnstable", "Berkshire", "Bristol", "Dukes", "Essex", "Franklin",
                               "Hampden", "Hampshire", "Middlesex", "Nantucket", "Norfolk",
                               "Plymouth", "Suffolk", "Worcester"))+
  scale_y_continuous(labels = function(x) paste0(x*100, "%"), expand = c(0, 0), limits = c(0, 0.17))+
  theme_classic()+
  theme(legend.position="bottom", text=element_text(family="Times"),
        axis.text=element_text(size=14), axis.title=element_text(size=14,face="bold"),
        legend.title= element_text(size=12), legend.text= element_text(size=12))

fig6


