library(tidyverse)
library(lubridate)
library(Hmisc)

###This code creates Figure 1 and Figure 4. 

#prep data
#read in data
dat <- readRDS("replication_code/data/state_yr_month_full_panel.rds")

#transform proxy variables to divide by population
data <- dat %>% 
  select(-bgchecks)%>%
  mutate_at(vars(lfp:ffl),~.x/CENSUS2010POP) 

##############################################################################
###Figure 1: LFP over time ###################################################
##############################################################################
windowsFonts(Times=windowsFont("Times New Roman"))

#plot with y-axis starting at origin. 
fig1<-ggplot(data, aes(x = month_yr, y= lfp)) +
  geom_point(col="black")+geom_line(col="black")+
  labs(x = "Time", y= "LFP/Pop.")+ 
  scale_y_continuous(labels = function(x) paste0(x*100, "%"), expand = c(0, 0), limits = c(0, 0.08))+
  theme_classic()+
  theme(axis.text=element_text(size=14, family="Times"), axis.title=element_text(size=14,face="bold", family="Times"),
        plot.title = element_text(size = 24, face = "bold", family="Times"))

fig1


#################################################################################
###FIGURE 4: Retail Proxies Over Time
#################################################################################

# Generate correlation of proxies against lfp
#correlation number
lfp_cor <- round(rcorr(x = as.matrix(data %>% select(-month_yr, -year, -month, -numeric_month_yr, -CENSUS2010POP)), type="pearson")$r[1, ], digits=3)
lfp_cor

#p-values
lfp_pval <- round(rcorr(x = as.matrix(data %>% select(-month_yr, -year, -month, -numeric_month_yr, -CENSUS2010POP)), type="pearson")$P[1, ], digits=2)
lfp_pval

#function to show percentages
fancy_scientific <- function(l) {
  # turn in to character string in scientific notation
  l <- l*100
  l <- format(l, scientific = FALSE)
  # return this as an expression
  parse(text=l)
  paste0(l,"%")
}

windowsFonts(Times=windowsFont("Times New Roman"))
#Figure 4 (A) - STR/Pop.
#Graph with y-axis starting at origin. 
str<-ggplot(data, aes(x = month_yr, y= str)) +
  geom_point(col="black")+geom_line(col="black")+
  geom_text(aes(x=as.Date("2010-01-01"), y=Inf,
                hjust=-0.1,vjust= 1,
                label="r = 0.76*"),
            size=5,
            family="Times")+
  labs(x = "Time", y= "STR/Pop.")+ 
  scale_y_continuous(labels = fancy_scientific,expand = c(0, 0), limits = c(0, 0.003))+
  theme_classic()+
  theme(axis.text=element_text(size=14, family="Times"), axis.title=element_text(size=14,face="bold", family="Times"),
        plot.title = element_text(size = 24, face = "bold", family="Times"))
str

#Figure 4 (B) - Cume STR/Pop.
cumstr<-ggplot(data, aes(x = month_yr, y= cumstr)) +
  geom_point(col="black")+geom_line(col="black")+
  geom_text(aes(x=as.Date("2010-01-01"), y=Inf,
                hjust=-0.1,vjust= 1,
                label="r = 0.998*"),
            size=5,
            family="Times")+
  labs(x = "Time", y= "Cumulative STR/Pop.")+ 
  scale_y_continuous(labels = fancy_scientific,expand = c(0, 0), limits = c(0, 0.16))+
  theme_classic()+
  theme(axis.text=element_text(size=14, family="Times"), axis.title=element_text(size=14,face="bold", family="Times"),
        plot.title = element_text(size = 24, face = "bold", family="Times"))
cumstr

#Figure 4 (C) - OS/Pop.
os<-ggplot(data, aes(x = month_yr, y= os)) +
  geom_point(col="black")+geom_line(col="black")+
  geom_text(aes(x=as.Date("2010-01-01"), y=Inf,
                hjust=-0.1,vjust= 1,
                label="r = 0.47*"),
            size=5,
            family="Times")+
  labs(x = "Time", y= "OS/Pop.")+ 
  scale_y_continuous(labels = fancy_scientific,expand = c(0, 0), limits = c(0, 0.015))+
  theme_classic()+
  theme(axis.text=element_text(size=14, family="Times"), axis.title=element_text(size=14,face="bold", family="Times"),
        plot.title = element_text(size = 24, face = "bold", family="Times"))
os

#Figure 4 (D) - cumulative OS/Pop.
cumos<-ggplot(data, aes(x = month_yr, y= cumos)) +
  geom_point(col="black")+geom_line(col="black")+
  geom_text(aes(x=as.Date("2010-01-01"), y=Inf,
                hjust=-0.1,vjust= 1,
                label="r = 0.998*"),
            size=5,
            family="Times")+
  labs(x = "Time", y= "Cumulative OS/Pop.")+ 
  scale_y_continuous(labels = fancy_scientific,expand = c(0, 0), limits = c(0, 0.7))+
  theme_classic()+
  theme(axis.text=element_text(size=14, family="Times"), axis.title=element_text(size=14,face="bold", family="Times"),
        plot.title = element_text(size = 24, face = "bold", family="Times"))
cumos

#Figure 4 (E) - change in FFL/Pop.
deltaffl<-ggplot(data, aes(x = month_yr, y= deltaffl)) +
  geom_point(col="black")+geom_line(col="black")+
  geom_text(aes(x=as.Date("2010-01-01"), y=Inf,
                hjust=-0.1,vjust= 1,
                label="r = -0.26"),
            size=5,
            family="Times")+
  labs(x = "Time", y= "Change in FFL/Pop.")+ 
  scale_y_continuous(labels = fancy_scientific)+
  theme_classic()+
  theme(axis.text=element_text(size=14, family="Times"), axis.title=element_text(size=14,face="bold", family="Times"),
        plot.title = element_text(size = 24, face = "bold", family="Times"))
deltaffl

#Figure 4 (F) - FFL/Pop.
#Graph with y-axis starting at origin. 
ffl<-ggplot(data, aes(x = month_yr, y= ffl)) +
  geom_point(col="black")+geom_line(col="black")+
  geom_text(aes(x=as.Date("2010-01-01"), y=Inf,
                hjust=-0.1,vjust= 1,
                label="r = 0.73*"),
            size=5,
            family="Times")+
  labs(x = "Time", y= "FFL/Pop.")+ 
  scale_y_continuous(labels = fancy_scientific,expand = c(0, 0), limits = c(0, 8.0e-05))+
  theme_classic()+
  theme(axis.text=element_text(size=14, family="Times"), axis.title=element_text(size=14,face="bold", family="Times"),
        plot.title = element_text(size = 24, face = "bold", family="Times"))
ffl

