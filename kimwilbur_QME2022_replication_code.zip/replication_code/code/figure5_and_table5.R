library(tidyverse)
library(lubridate)
library(Hmisc)

##This code produces Figure 5 and Table 5 which assesses how FBI background 
#checks correlate with other proxies

#read in data
dat <- readRDS("replication_code/data/state_yr_month_full_panel.rds")

#transform proxy variables to divide by population
data <- dat %>% 
  mutate_at(vars(lfp:bgchecks),~.x/CENSUS2010POP) 

###########################################################################
##Figure 5 FBI Background checks vs STR %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
###########################################################################
#select bgchecks, str
#make dataframe long format to plot graph
data_long <- data %>% 
  select(month_yr, str, bgchecks) %>%
  gather(proxy, value, str: bgchecks)

#plot graph
windowsFonts(Times=windowsFont("Times New Roman"))
fig5 <- data_long %>%
  ggplot(aes(x=month_yr, y=value, shape=proxy))+geom_line()+geom_point()+
  labs(x = "Time", y= "Percentage")+ 
  scale_y_continuous(labels = function(x) paste0(x*100, "%"), expand = c(0, 0), limits = c(0, 0.005))+
  theme_classic()+
  theme(legend.position="bottom", text=element_text(family="Times"), axis.text=element_text(size=14), axis.title=element_text(size=14,face="bold"),
        plot.title = element_text(size = 24, face = "bold"), legend.title= element_text(size=12), legend.text= element_text(size=12))+
  scale_shape_manual(name="Proxies", labels=c("STR/Pop.", "Background Checks/Pop."),
                     values=c(16, 2))

fig5


###########################################################################
##Table 5 State-month correlations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
###########################################################################
#create new dataframe that reorders variables
cordat <- data %>% 
  select(lfp, bgchecks, str, os, ffl)
#correlation matrix
cordat<-rcorr(as.matrix(cordat))
cordatr <- as.data.frame(cordat$r)
round(cordatr, 2)
#pvalues
cordatp <- as.data.frame(cordat$P)
round(cordatp, 2)

