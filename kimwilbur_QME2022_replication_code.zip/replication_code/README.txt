The following code and data create the tables and figures created in the paper
Kim and Wilbur (2022) "Proxies for Legal Firearm Prevalence." 

All code files are available in the code folder. The code files are organized by figure and table numbers, it will be self-explanatory by the code file name. 
All cross-sectional and panel data used in the paper are available in the data folder. We share the panel data we assembled, we are unable to share the original data sources. 

We do not include the suicide variables in the panel data for replication due to the granularity (<10 counts) in geography and time
which we are prohibited to share. The suicide data is from the Multiple Causes of Death (MCOD)files from the National Center of Health Statistics (NCHS) division
of the Centers for Disease Control and Prevention (CDC). You can request for suicide data through https://www.cdc.gov/nchs/nvss/nvss-restricted-data.htm

Therefore, the replication code only replicates the retail-based proxy findings.
Going through each code file will show which data file to use. 





 